
<?php



$con= mysqli_connect("localhost","root","","forms");
   $id=$_GET['id'];

  $sql1="SELECT * FROM `upload_img`";
  $query1 = mysqli_query($con, $sql1);
  while($row=mysqli_fetch_array($query1))
  {
      $username=$row['username'];
      $image=$row['image'];

      echo $image;
      echo "<br>";
      echo $username;
    
  }



?>

<!-- <php

if(isset($_POST['update']))
{
$con= mysqli_connect("localhost","root","","forms");
   $id=$_GET['id'];

   $username=$_POST['username'];
   $image=$_POST['image'];

   $sql1="UPDATE `upload_img` SET `username`='$username',`image`='$image' WHERE `id`='$id'";
   $query1=mysqli_query($con,$sql1);
   if($query)
  {
      header("location:upload.php");
  }


}
?> -->




<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js">
    </script>
    <title>Document</title>
</head>
<form action="" method="post" enctype="multipart/form-data">
    <h1>Forms</h1>

    <div class="form-input-group m-auto d-block">
        <span class="form-input-group" id="addon-wrapping">Name: </span>
        <input type="text" class="form-control-group" name="username" value="<?php echo  $username; ?>" aria-label="Username" aria-describedby="addon-wrapping">
    </div>
    <br>
    <div class="form-input-group m-auto d-block">
      <label for="">Profile Pic: </label>
        <input type="file" class="form-control-group" name="image" value="<?php echo  $image; ?>" aria-label="Username" aria-describedby="addon-wrapping">
    </div>
    <br>
    <input type="hidden" name="id" value="<?php echo $_GET['id'];?>">
              <br>
    <button type="submit" class="btn btn-success" name="update">Upload</button>

</form>

<body>

</body>

</html>