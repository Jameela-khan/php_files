<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js">
    </script>
    <title>Document</title>
</head>
<form action="upload.php" method="post" enctype="multipart/form-data">
    <h1>Forms</h1>

    <div class="form-input-group m-auto d-block">
        <span class="form-input-group" id="addon-wrapping">Name: </span>
        <input type="text" class="form-control-group" name="username" aria-label="Username" aria-describedby="addon-wrapping">
    </div>
    <br>
    <div class="form-input-group m-auto d-block">
      <label for="">Profile Pic: </label>
        <input type="file" class="form-control-group" name="image" aria-label="Username" aria-describedby="addon-wrapping">
    </div>
    <br>
    <button type="submit" class="btn btn-success" name="submit">Upload</button>

</form>

<body>

</body>

</html>