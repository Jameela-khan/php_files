<?php
$con = mysqli_connect('localhost','root');
mysqli_select_db($con, 'forms');

if(isset($_POST['submit'])){
    $username=$_POST['username'];
    $files=$_FILES['image'];

    // print_r($username);
    // echo"<br>";
    // print_r($files);
    $filename = $files['name'];
    $fileerror = $files['error'];
    $filetmp = $files['tmp_name'];
    $fileext  = explode('.',$filename);
    $filecheck= strtolower(end($fileext));
    $fileextstored=array('png','jpg','jpeg');
    if(in_array($filecheck, $fileextstored))
    $destinationfile = "upload/".$filename;
    move_uploaded_file($filetmp, $destinationfile);
    $sql= "INSERT INTO `upload_img`(`username`, `image`) VALUES ('$username','$destinationfile')";
    $query=mysqli_query($con,$sql);
}

?>

<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js">
    </script>
    <title>Document</title>
</head>

<body>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Id</th>
                <th scope="col">username</th>
                <th scope="col">Image</th>
                <th scope="col">Access</th>
            </tr>
        </thead>
        <tbody>
<?php
$con = mysqli_connect('localhost','root');
mysqli_select_db($con, 'forms'); 

$sql1="SELECT * FROM `upload_img`";
$query_display=mysqli_query($con,$sql1);
while($row=mysqli_fetch_array($query_display))
{


?>

<tr>
    <td><?php echo $row['id'];?></td>
     <td><?php echo $row['username'];?></td>
      <td><img src="<?php echo $row['image'];?>" height="100px" width="100px"></td>
      <td><button class="btn btn-success"><a style="color:white;" href="edit.php?id=<?php echo $row['id']; ?>">Edit</a></button>&nbsp;<button class="btn btn-success"><a href="delete.php?id=<?php echo $row['id']; ?>" style="color:white;">Delete</a></button></td>
</tr>
            <?php }
            ?>
        </tbody>
    </table>
</body>

</html>